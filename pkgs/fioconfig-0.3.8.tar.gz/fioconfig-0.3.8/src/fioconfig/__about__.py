#! /usr/bin/env python3

from pkg_resources import get_distribution, DistributionNotFound
try:
    __version__ = get_distribution("fioconfig").version
except DistributionNotFound:
    __version__ = "Unknown Version"

__title__ = 'fioconfig'
__description__ = 'Python library to create and manipulate FIO configuration files.'
__url__ = 'http://www.vmware.com/'
__build__ = 0x00031
__author__ = 'Charles Lee'
__author_email__ = 'charlesl@vmware.com'
__license__ = 'MIT'
__cake__ = u'\u2728 \U0001f370 \u2728'
