import uuid

from pathlib import Path
from unittest import TestCase

from fioconfig.fiobssplit import FioBsSplit
from fioconfig.fiocontinueonerror import FioContinueOnError
from fioconfig.fioiogenine import FioIoEngine
from fioconfig.fiojob import FioJob
from fioconfig.fiopercentagerandom import FioPercentageRandom
from fioconfig.fiorateiops import FioRateIops
from fioconfig.fiorateprocess import FioRateProcess
from fioconfig.fioreadwrite import FioReadWrite
from fioconfig.fiosize import FioSize


class TestFioJob(TestCase):

    def test_properties(self):

        # 1.12.3. Job description
        job = FioJob('global')
        job.description = 'This is the job description.'
        job.loops = 1
        job.numjobs = 1

        # 1.12.4. Time related parameters
        job.runtime = 10
        job.time_based = True

        # 1.12.5. Target file/device
        job.directory = Path('/tmp')
        job.filename = [Path('/tmp/%s' % str(uuid.uuid4())) for _ in range(4)]

        # 1.12.6. I/O type
        job.direct = True
        job.norandommap = True
        job.readwrite = FioReadWrite.create('randrw')
        job.percentage_random = FioPercentageRandom('60,20,20')

        # 1.12.7. Block size
        job.blocksize = FioSize('64K')
        job.bssplit = FioBsSplit('4k/50:1k/:32k/')
        job.iodepth_batch = 32

        # 1.12.9. I/O size
        job.size = FioSize("128G")

        # 1.12.10. I/O engine
        job.ioengine = FioIoEngine.create('libaio')

        # 1.12.11. I/O engine specific parameters
        job.cpuload = 4
        job.cpuchunks = 10

        # 1.12.12. I/O depth
        job.iodepth = 8
        job.iodepth_batch = 16

        #  1.12.13. I/O rate
        job.rate_process = FioRateProcess.create('poisson')
        job.rate_iops = FioRateIops('500,500')

        # 1.12.19. Measurements and reporting
        job.group_reporting = True
        job.disk_util = False

        # 1.12.20. Error handling
        job.continue_on_error = FioContinueOnError.create('all')

