import ast
from pathlib import Path
from sys import exit

import click

from fioconfig.__about__ import __version__
from fioconfig.fioconfig import FioConfig


@click.group()
@click.version_option(version=__version__)
def cli():
    pass


# https://stackoverflow.com/questions/47631914/how-to-pass-several-list-of-arguments-to-click-option
class PythonLiteralOption(click.Option):
    def type_cast_value(self, ctx, value):
        try:
            values = ast.literal_eval(value)
        except Exception:
            raise click.BadParameter(value)

        if isinstance(values, int):
            if values < 1:
                raise click.BadParameter("Value %s not valid." % values)
            return [values, ]

        if isinstance(values, tuple):

            if len(values) > 3:
                raise click.BadParameter("Too many values: %s (max 3: read, write, trim)." % value)

            for x in values:
                if x < 1:
                    raise click.BadParameter("Value %s in %s is not valid." % (x, value))
            return list(values)

        raise click.BadParameter(value)


@cli.command('create')
@click.option('-b', 'block_size', type=str, required=True, help='Block size')
@click.option('-e', 'testing_time', type=click.IntRange(min=1), required=True, help='Testing time (seconds)')
@click.option('-n', 'nb_disks', type=click.IntRange(min=1, max=60), required=True, help='Number of data disks')
@click.option('-r', 'read_pct', type=click.IntRange(min=0, max=100), required=True, help='Read percentage')
@click.option('-s', 'random_pct', type=click.IntRange(min=0, max=100), required=True, help='Random percentage')
@click.option('-w', 'working_set', type=click.IntRange(min=1, max=100), required=True, help='Working set percentage')
@click.option('-m', 'warmup_time', type=click.IntRange(min=1), help='Warmup time (seconds)')
@click.option('-o', 'io_rate', cls=PythonLiteralOption, help='IO Rate')
@click.option('-p', 'profile_prefix', help='Profile prefix')
@click.option('-t', 'nb_threads', type=click.IntRange(min=1), default=1, help='Number of threads per data disk')
@click.option('-j', 'nb_jobs', type=click.IntRange(min=1, max=64), required=False, help='Number of jobs')
@click.option('-c', 'cpu_load', type=click.IntRange(min=1, max=100), help='CPU utilization percentage')
@click.option('-nc', 'nb_cpu', type=click.IntRange(min=1), help='Number of CPU to run')
@click.option('-d', 'output_directory',
              type=click.Path(exists=True, file_okay=False, resolve_path=True),
              default=".", help='Output directory')
def create(block_size: str,
           testing_time: int,
           nb_disks: int,
           read_pct: int,
           random_pct: int,
           working_set: int,
           warmup_time: int,
           io_rate: int,
           profile_prefix: str,
           nb_threads: int,
           nb_jobs: int,
           cpu_load: int,
           nb_cpu: int,
           output_directory: str):
    header = '; Auto generated FIO parameter file\n' + \
             '; block_size:     ' + str(block_size) + '\n' + \
             '; testing_time:   ' + str(testing_time) + ' \n' + \
             '; warmup_time:    ' + str(warmup_time) + '\n' + \
             '; nb_disks:       ' + str(nb_disks) + '\n' + \
             '; io_rate:        ' + str(io_rate) + '\n' + \
             '; read_pct:       ' + str(read_pct) + '\n' + \
             '; random_pct:     ' + str(random_pct) + '\n' + \
             '; nb_threads:     ' + str(nb_threads) + '\n' + \
             '; working_set:    ' + str(working_set) + '\n'

    if profile_prefix:
        params = (profile_prefix, nb_disks, working_set, block_size, read_pct, random_pct, nb_threads)
        output_file = Path(output_directory) / ('%s-fio-%dvmdk-%dws-%s-%drdpct-%drandompct-%dthreads' % params)
    else:
        params = (nb_disks, working_set, block_size, read_pct, random_pct, nb_threads)
        output_file = Path(output_directory) / ('fio-%dvmdk-%dws-%s-%drdpct-%drandompct-%dthreads' % params)

    if nb_jobs is not None:
        output_file = Path(str(output_file) + '-%djobs' % nb_jobs)
        header += '; nb_jobs:        ' + str(nb_jobs)

        if nb_jobs > nb_disks:
            header += ' - Warning: There were more jobs specified than disks\n'
        else:
            header += '\n'

    if not (cpu_load is None) and not (nb_cpu is None):
        output_file = Path(str(output_file) + '-%dcpu-%dcpupct' % (nb_cpu, cpu_load))
        header += '; nb_cpus:        ' + str(nb_cpu) + '\n' + \
                  '; cpuio:          ' + str(cpu_load) + '\n'

    try:
        FioConfig(block_size=block_size,
                  testing_time=testing_time,
                  nb_disks=nb_disks,
                  read_percentage=read_pct,
                  seek_percentage=random_pct,
                  working_set=working_set,
                  warmup_time=warmup_time,
                  io_rate=io_rate,
                  nb_threads=nb_threads,
                  nb_jobs=nb_jobs,
                  cpu_load=cpu_load,
                  nb_cpu=nb_cpu
                  ).write(output_file, header)

    except ValueError as e:
        click.echo('error: invalid value: %s' % str(e), err=True)
        exit(1)

    except Exception as e:
        click.echo('error: %s' % str(e), err=True)
        exit(1)

    else:
        click.echo('Output file: %s' % output_file)
