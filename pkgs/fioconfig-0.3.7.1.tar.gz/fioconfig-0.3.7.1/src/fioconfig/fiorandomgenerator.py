import inspect

from enum import Enum
from typeguard import typechecked
from typing import List

from fioconfig.fioclocksources import FioClockSource


class FioRandomGenerator(Enum):
    """ FIO Random Generators
        Desc:   Fio supports the following engines for generating I/O offsets for random I/O
        Values: - tausworthe: Strong 2^88 cycle random number generator.
                - lfsr: Linear feedback shift register generator
                - tausworthe64: Strong 64-bit 2^258 cycle random number generator
        Ref.    https://fio.readthedocs.io/en/latest/fio_doc.html#i-o-type
        """
    tausworthe = 1
    lfsr = 2
    tausworthe64 = 3

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioRandomGenerator':
        for item in cls:
            if item.name == name:
                return item
        raise ValueError('Enumeration FioRandomGenerator' +
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function +
                         'Input does not match a known type '
                         'Received: %s ' % name)

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        return any(name == item.name for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioClockSource']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    def __str__(self) -> str:
        switch = {
            FioRandomGenerator.tausworthe.value: 'tausworthe',
            FioRandomGenerator.lfsr.value: 'lfsr',
            FioRandomGenerator.tausworthe64.value: 'tausworthe64',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()
