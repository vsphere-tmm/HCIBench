import inspect
import re

from typeguard import typechecked
from typing import Union

from fioconfig.fiosizeunit import FioSizeUnit

FIOSIZE_PATTERN_1 = re.compile(r'([0-9]+)')
FIOSIZE_PATTERN_2 = re.compile(r'([0-9]+)(percent|[a-z]{0,2}|%)', re.IGNORECASE)


class FioSize(object):

    def __init__(self, value: str):

        result = FIOSIZE_PATTERN_1.fullmatch(value)
        if result:
            self.size = int(result.group(1))
            self.unit = None
            return

        result = FIOSIZE_PATTERN_2.fullmatch(value)
        if result:
            self.size = int(result.group(1))
            self.unit = FioSizeUnit.create(result.group(2))

            if self.unit == FioSizeUnit.Percent and self.size > 100:
                raise ValueError('Class FioSize ' +
                                 'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                 'Input unit is percentage but value is out of range ' +
                                 'Expected range: [0,100] ' +
                                 'Received: %d' % self.size)
            return

        raise ValueError('Class FioSize ' +
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function +
                         'Input does not match a known pattern '
                         'Received: %s' % value)

    #
    # Properties
    #

    # size
    @property
    def size(self) -> int:
        return self._size

    @size.setter
    @typechecked()
    def size(self, value: int):
        self._size = value

    # unit
    @property
    def unit(self) -> Union[FioSizeUnit, None]:
        return self._unit

    @unit.setter
    @typechecked()
    def unit(self, value: Union[FioSizeUnit, None]):
        self._unit = value

    #
    # Builtin
    #

    def __eq__(self, other):
        if type(other) is type(self):
            return self.size == other.size and self.unit == other.unit
        else:
            return False

    def __str__(self):
        if self.unit:
            return '%d%s' % (self.size, self.unit)
        return '%d' % self.size

    def __repr__(self):
        return self.__str__()

