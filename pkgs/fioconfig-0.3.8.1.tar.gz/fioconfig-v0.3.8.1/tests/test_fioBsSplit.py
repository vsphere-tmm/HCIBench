import inspect
import threading
from unittest import TestCase

from fioconfig.fiobssplit import FioBsSplit


class TestFioBsSplit(TestCase):

    test_results = list()
    test_results_lock = threading.Lock()
    classname = None

    pass

    #
    # Tests
    #
    def test___init__(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function
        FioBsSplit('10k/40')
        FioBsSplit('4k/10:64k/50:32k/40')
        FioBsSplit('4k/50:1k/:32k/')
        FioBsSplit('10k/40')


