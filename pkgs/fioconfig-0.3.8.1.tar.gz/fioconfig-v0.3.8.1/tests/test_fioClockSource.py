import inspect
import string
import threading

import numpy as np

from unittest import TestCase

from fioconfig.fioclocksources import FioClockSource

NB_SAMPLES = 100
INT_MIN = -100
INT_MAX = 10000


class TestFioClockSource(TestCase):

    test_results = list()
    test_results_lock = threading.Lock()
    classname = None

    @classmethod
    def setUpClass(cls):
        cls.sources = [FioClockSource.cpu, FioClockSource.gettimeofday, FioClockSource.clock_gettime]
        cls.names_valid = [item.name for item in cls.sources]
        cls.values_valid = [item.value for item in cls.sources]

        # Generate some random string but exclude any valid names
        cls.names_invalid = [name for name in [''.join(
            np.random.choice(list(string.ascii_lowercase) + list(string.ascii_uppercase)) for _ in
            range(np.random.randint(1, 32))) for _ in
            range(NB_SAMPLES)] if name not in cls.names_valid]

        # Generate some random numbers but exclude any valid values
        cls.values_invalid = [int(value) for value in np.random.randint(INT_MIN, INT_MAX, size=(NB_SAMPLES,)) if
                              value not in cls.values_valid]

        cls.classname = cls().__class__.__name__

    @classmethod
    def tearDownClass(cls):
        total = int(0)
        test_summary = ''

        cls.test_results_lock.acquire()
        for fname, count in cls.test_results:
            test_summary += 'Method %s.%s: %d tests\n' % (cls.classname, fname, count)
            total += count
        cls.test_results_lock.release()

        print('%sClass %s total: %d tests' % (test_summary, cls.classname, total))

    @classmethod
    def add_result(cls, fname, count):
        cls.test_results_lock.acquire()
        cls.test_results.append((fname, count))
        cls.test_results_lock.release()

    def setUp(self):
        self.count = int(0)

    def tearDown(self):
        # Make sure we tested something, otherwise add tests count
        self.assertTrue(self.count > 0, msg='Method %s had 0 tests cases' % self.fname)
        self.add_result(self.fname, self.count)

    #
    # Tests
    #
    def test_create(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        for source in self.sources:
            tmp = FioClockSource.create(source.name)
            self.assertTrue(source == tmp,
                            msg='Method %s Expected: %s Received: %s' % (self.fname, source.name, tmp.name))
            self.count += 1

        for name in self.names_invalid:
            with self.assertRaises(ValueError,
                                   msg='Method %s Input: %s failed to raise exception' % (self.fname, name)):
                self.count += 1
                FioClockSource.create(name)

    def test_name(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        for name in self.names_valid:
            self.assertTrue(FioClockSource.has_name(name), msg='Method %s missing value: %s' % (self.fname, name))
            self.count += 1

        for name in FioClockSource.get_all_name():
            self.assertTrue(name in self.names_valid,
                            msg='Method %s missing value in tests data: %s' % (self.fname, name))
            self.count += 1

        for name in self.names_invalid:
            self.assertFalse(name in self.names_valid, msg='Method %s false positive: %s' % (self.fname, name))
            self.count += 1

    def test_value(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        for value in self.values_valid:
            self.assertTrue(FioClockSource.has_value(value), msg='Method %s missing value: %s' % (self.fname, value))
            self.count += 1

        for value in FioClockSource.get_all_value():
            self.assertTrue(value in self.values_valid,
                            msg='Method %s missing value in tests data: %s' % (self.fname, value))
            self.count += 1

        for value in self.values_invalid:
            self.assertFalse(value in self.values_valid, msg='Method %s false positive: %s' % (self.fname, value))
            self.count += 1

    def test_member(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        for source in self.sources:
            self.assertTrue(source in FioClockSource, msg='Method %s missing value: %s' % (self.fname, source))
            self.count += 1

        for source in FioClockSource.get_all_member():
            self.assertTrue(source in self.sources,
                            msg='Method %s missing value in tests data: %s' % (self.fname, source))
            self.count += 1

    def test_get_all_name(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        names = FioClockSource.get_all_name()

        for name in self.names_valid:
            self.assertTrue(name in names, msg='Method %s missing value: %s' % (self.fname, name))
            self.count += 1

        for name in names:
            self.assertTrue(name in self.names_valid,
                            msg='Method %s missing value in tests data: %s' % (self.fname, name))
            self.count += 1

    def test_get_all_value(self):
        self.fname = inspect.getframeinfo(inspect.currentframe()).function

        values = FioClockSource.get_all_value()

        for value in self.values_valid:
            self.assertTrue(value in values, msg='Method %s missing value: %s' % (self.fname, value))
            self.count += 1

        for value in values:
            self.assertTrue(value in self.values_valid,
                            msg='Method %s missing value in tests data: %s' % (self.fname, value))
            self.count += 1
