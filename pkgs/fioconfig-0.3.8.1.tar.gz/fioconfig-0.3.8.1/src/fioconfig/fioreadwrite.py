import inspect

from enum import Enum
from typeguard import typechecked
from typing import List


class FioReadWrite(Enum):
    """ FIO Read Write
        Desc:   Fio defaults to read if the option is not specified. For the mixed I/O types, the default is to split
                them 50/50. For certain types of I/O the result may still be skewed a bit, since the speed may be
                different.

                It is possible to specify the number of I/Os to do before getting a new offset by appending :<nr> to
                the end of the string given. For a random read, it would look like rw=randread:8 for passing in an
                offset modifier with a value of 8. If the suffix is used with a sequential I/O pattern, then the <nr>
                value specified will be added to the generated offset for each I/O turning sequential I/O into
                sequential I/O with holes. For instance, using rw=write:4k will skip 4k for every write. Also see the
                rw_sequencer option.

        Values: - read: Sequential reads.
                - write: Sequential writes.
                - trim: Sequential trims (Linux block devices and SCSI character devices only).
                - randread: Random reads.
                - randwrite: Random writes.
                - randtrim: Random trims (Linux block devices and SCSI character devices only).
                - readwrite: Sequential mixed reads and writes.
                - rw: Sequential mixed reads and writes.
                - randrw: Random mixed reads and writes.
                - trimwrite: Sequential trim+write sequences. Blocks will be trimmed first, then the same blocks will
                             be written to.
    """

    read = 1
    write = 2
    trim = 3
    randread = 4
    randwrite = 5
    randtrim = 6
    readwrite = 7
    rw = 8
    randrw = 9
    trimwrite = 10

    @classmethod
    @typechecked
    def create(cls, name: str) -> 'FioReadWrite':
        for item in cls:
            if item.name == name:
                return item
        raise ValueError('Enumeration FioReadWrite ' +
                         'Method %s' % inspect.getframeinfo(inspect.currentframe()).function +
                         'Input does not match a known type ' +
                         'Received: %s' % name)

    @classmethod
    @typechecked
    def has_name(cls, name: str) -> bool:
        return any(name.upper() == item.name.upper() for item in cls)

    @classmethod
    @typechecked
    def has_value(cls, value: int) -> bool:
        return any(value == item.value for item in cls)

    @classmethod
    @typechecked
    def get_all_member(cls) -> List['FioReadWrite']:
        return [item for item in cls]

    @classmethod
    @typechecked
    def get_all_name(cls) -> List[str]:
        return [item.name for item in cls]

    @classmethod
    @typechecked
    def get_all_value(cls) -> List[int]:
        return [item.value for item in cls]

    def __str__(self) -> str:
        switch = {
            FioReadWrite.read.value: 'read',
            FioReadWrite.write.value: 'write',
            FioReadWrite.trim.value: 'trim',
            FioReadWrite.randread.value: 'randread',
            FioReadWrite.randwrite.value: 'randwrite',
            FioReadWrite.randtrim.value: 'randtrim',
            FioReadWrite.readwrite.value: 'readwrite',
            FioReadWrite.rw.value: 'rw',
            FioReadWrite.randrw.value: 'randrw',
            FioReadWrite.trimwrite.value: 'trimwrite',
        }
        return switch.get(self.value)

    def __repr__(self):
        return self.__str__()
