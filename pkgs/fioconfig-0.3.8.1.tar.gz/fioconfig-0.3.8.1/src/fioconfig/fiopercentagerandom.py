import inspect

from typeguard import typechecked
from typing import List
from typing import Union


class FioPercentageRandom(object):

    class FioPercentageRandomValid(object):
        """ Valid values for the FioPercentageRandom class """
        percentage_random_min = 0
        percentage_random_max = 100

    # Class variables
    __valid = FioPercentageRandomValid()

    def __init__(self, value: Union[List[int], str]):
        self.percentage_random = value

    #
    # Properties
    #

    # percentage_random
    @property
    def percentage_random(self) -> List[int]:
        return self._percentage_random

    @percentage_random.setter
    @typechecked()
    def percentage_random(self, value: Union[List[int], str]):

        self._percentage_random = []
        if isinstance(value, list):
            for item in value:
                if item < self.__valid.percentage_random_min or item > self.__valid.percentage_random_max:
                    raise ValueError('Class FioPercentageRandom ' +
                                     'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                     'Input unit is percentage but value is out of range ' +
                                     'Expected range: [1,100] ' +
                                     'Received: %s' % item)
                self._percentage_random.append(item)
        else:
            for item in value.split(','):
                if int(item) < self.__valid.percentage_random_min or int(item) > self.__valid.percentage_random_max:
                    raise ValueError('Class FioPercentageRandom ' +
                                     'Method %s ' % inspect.getframeinfo(inspect.currentframe()).function +
                                     'Input unit is percentage but value is out of range ' +
                                     'Expected range: [1,100] ' +
                                     'Received: %s' % item)
                self._percentage_random.append(int(item))

    #
    # Builtin
    #
    def __str__(self) -> str:
        value = ''
        first = True
        for item in self._percentage_random:
            if first:
                value += '%s' % item
                first = False
            else:
                value += ',%s' % item
        return value
